<form method="post" action="post.php">
<img src="captcha.php?random=<?echo(mt_rand());?>"/><br/><br/>
<input type="text" name="captcha" size="10"/> <input type="submit" value="Submit"/>
</form>