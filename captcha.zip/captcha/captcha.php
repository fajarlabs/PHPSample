<?
	class RandomChar{
		function LoopChar($min, $max){
			for($i=$min;$i<=$max;$i++){
				$ret .= chr($i);
			}
			return($ret);
		}
		
		function GenerateRandomChar($digit, $capital, $small, $number){
			if($number) $data = $this->LoopChar(48, 57);
			if($capital) $data .= $this->LoopChar(65, 90);
			if($small) $data .= $this->LoopChar(97, 122);
			
			$ret = $data[mt_rand(0, (strlen($data)-1))];
			for($i=1;$i<$digit;$i++){
				$ret .= $data[mt_rand(0, (strlen($data)-1))];
			}
			return($ret);
		}
	}
	
	class captcha extends RandomChar{
		function captcha(&$session, $width, $height, $chars){
			$fontfile 	= "comic.ttf";
			$fontsize 	= 11;
			
			$code 	= $this->GenerateRandomChar($chars, true, false, false);
			//$imgBg	= imagecreatefromjpeg("captcha/captchabg.jpg");
			$imgDst = imagecreate($width, $height);
			//imagecopy($imgDst, $imgBg, 
			//			0, 0, 0, 0, 
			//			imageSX($imgBg), 
			//			imageSY($imgBg));
			imagecolorallocate($imgDst, 255, 255, 255);
			
			//dots
			$area = ($width*$height)/5;
			$dots_color = imagecolorallocate($imgDst, 255, 0, 255);
			for($i=0;$i<$area;$i++){
				imagefilledellipse($imgDst, mt_rand(0, $width), mt_rand(0, $height),
									1, 1, $dots_color);
			}
			
			//text
			$textbox	= imagettfbbox($fontsize, 0, $fontfile, $code);
			$textcolor 	= imagecolorallocate($imgDst, 0, 0, 255);
			imagettftext($imgDst, $fontsize, 0, 
							($width-$textbox[4])/2, 
							($height-$textbox[5])/2, 
							$textcolor, 
							$fontfile, $code);

			imagejpeg($imgDst);
			//imageDestroy($imgBg);
			imageDestroy($imgDst);
			
			$session = $code;
		}
	}
	
	session_start();
	header("Content-type: image/jpeg");
	$width 	 = $_GET['width']  ? $_GET['width']  : 100;
	$height  = $_GET['height'] ? $_GET['height'] : 20;
	$chars	 = $_GET['chars']  ? $_GET['chars']  : 6;
	
	//$session = &$_SESSION['securityCode'];
	$captcha = new captcha($_SESSION['securityCode'], $width, $height, $chars);
?>