<?
	session_start();
	//Pengecekkan terhadap captcha yang di masukkan user Jika bernilai benar
	if(isset($_SESSION['securityCode']) && $_SESSION['securityCode'] == $_POST['captcha']){
		//Jalankan query yang ingin anda jalankan
		echo('Security Code Benar');
		unset($_SESSION['securityCode']);
	//Jika captcha yang di masukkan tidak benar /salah
	}else{
	//tampilkan pesan
		echo('Security Code Salah');
	}
?><br/>
<a href="index.php">[balik]</a>